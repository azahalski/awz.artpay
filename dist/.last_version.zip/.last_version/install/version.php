<?
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2025-06-13 21:00:00"
);
?>