<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/awz.artpay/template/template.php");