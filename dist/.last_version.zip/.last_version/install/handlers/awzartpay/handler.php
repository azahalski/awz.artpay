<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/awz.artpay/handlers/awzartpay/handler.php");